<!--Footer-->
<footer style="margin-top:5%;">
<div class="offset-lg-0 col-lg-12" container>
   <p class="foot">Copyright &copy; 2020 &middot; All Rights Reserved &middot; <a href="https://christiangallucci.github.io/Portfolio/index.html">Christian Gallucci</a></p>
   <p class="social">Follow us at:</p>
</div>
<div class="offset-lg-0 col-lg-12" container>
		<a href="https://www.facebook.com/Football-Club-of-New-York-FCNY-123454024399603/" target="_blank" class="fa fa-facebook-square" style="font-size:48px;margin-right:20px;"></a>
        <a href="https://www.instagram.com/jimneuburger/?hl=en" target="_blank" class="fa fa-instagram" style="font-size:48px;"></a>
</div>
<br>
</footer>
<!--end of footer-->